#!/bin/bash
# D Browser setup wizard (Linux). Double-click "Install D Browser" or run: ./install-wizard.sh   (uninstall: ./install-wizard.sh --uninstall)
cd "$(dirname "$0")" || exit 1
T="D Browser Setup"; GUI=0
command -v zenity >/dev/null 2>&1 && [ -n "$DISPLAY$WAYLAND_DISPLAY" ] && GUI=1
say(){ if [ $GUI = 1 ]; then zenity --info --title="$T" --width=440 --text="$1" 2>/dev/null; else printf '\n%s\n' "$1"; fi; }
ask(){ if [ $GUI = 1 ]; then zenity --question --title="$T" --width=440 --text="$1" --ok-label="${2:-Next}" --cancel-label="${3:-Cancel}" 2>/dev/null; else read -r -p "$1 [y/N] " a; [[ $a =~ ^[Yy] ]]; fi; }
asroot(){ if command -v pkexec >/dev/null 2>&1 && [ $GUI = 1 ]; then pkexec "$@"; else sudo "$@"; fi; }
busy(){ # busy "message" command...  -> shows a progress window while the command runs
  local m="$1"; shift; "$@" >setup.log 2>&1 & local p=$!
  if [ $GUI = 1 ]; then ( while kill -0 $p 2>/dev/null; do echo "# $m"; sleep 2; done; echo 100 ) | zenity --progress --pulsate --auto-close --no-cancel --title="$T" --width=440 2>/dev/null; else echo "$m"; fi
  wait $p; }
fail(){ say "Setup stopped: $1

Details were saved in setup.log:
$(tail -n 12 setup.log 2>/dev/null)"; exit 1; }

if [ "$1" = "--uninstall" ]; then
  ask "Remove D Browser from this computer?" "Remove" && asroot apt-get remove -y d-browser && rm -f ~/Desktop/d-browser.desktop && { ask "Also delete your D Browser settings, history and ad-block cache?" "Delete" "Keep" && rm -rf ~/.config/"D Browser" ~/.config/d-browser; }; say "D Browser was removed."; exit; fi

ask "Welcome to the D Browser setup wizard.

This installs D Browser, with D OS and the built-in ad blocker, on this computer." "Next" || exit 0
if [ $GUI = 1 ]; then zenity --text-info --title="$T - License" --width=520 --height=360 --filename=build/license.txt --checkbox="I accept the license terms" --ok-label="Next" 2>/dev/null || exit 0
else cat build/license.txt; ask "Accept the license?" || exit 0; fi

if [ $GUI = 1 ]; then
  MODE=$(zenity --list --radiolist --title="$T" --width=520 --height=260 --text="How would you like to install D Browser?" --column="" --column="Option" --column="Details" TRUE "menu" "Install for this computer (adds D Browser to the app menu, asks for your password)" FALSE "portable" "Portable (single file, no password needed)" --hide-column=2 --print-column=2 2>/dev/null) || exit 0
else read -r -p "Install type: [1] app menu (needs sudo)  [2] portable : " a; [ "$a" = 2 ] && MODE=portable || MODE=menu; fi

# requirements
getent hosts registry.npmjs.org >/dev/null 2>&1 || fail "no internet connection. Connect and run the wizard again."
nodev(){ node -v 2>/dev/null | sed 's/v\([0-9]*\).*/\1/'; }
V=$(nodev); if ! command -v npm >/dev/null 2>&1 || [ "${V:-0}" -lt 18 ]; then
  ask "D Browser needs Node.js 18 or newer to be built, and it was not found. Install it now?" "Install Node.js" || exit 0
  busy "Installing Node.js..." asroot apt-get install -y nodejs npm; V=$(nodev)
  { command -v npm >/dev/null 2>&1 && [ "${V:-0}" -ge 18 ]; } || fail "Node.js 18+ is still missing (your system offers an older version). Install it from https://nodejs.org or with nvm, then run the wizard again."
fi

busy "Building D Browser... this can take several minutes" bash -c 'npm install && npm run dist:linux' || fail "the build failed."
DEB="$PWD/dist/D Browser Setup.deb"; APP="$PWD/dist/D Browser Setup.AppImage"
if [ "$MODE" = menu ]; then
  [ -f "$DEB" ] || fail "the installer file was not created."
  busy "Installing D Browser..." asroot apt-get install -y "$DEB" || true
  command -v d-browser >/dev/null 2>&1 || fail "installation did not complete."
  RUN="d-browser"
  [ -d ~/Desktop ] && cp /usr/share/applications/d-browser.desktop ~/Desktop/ 2>/dev/null && chmod +x ~/Desktop/d-browser.desktop && gio set ~/Desktop/d-browser.desktop metadata::trusted true 2>/dev/null
else
  [ -f "$APP" ] || fail "the portable file was not created."
  mkdir -p ~/Applications ~/.local/share/applications ~/.local/share/icons
  cp "$APP" ~/Applications/D-Browser.AppImage; chmod +x ~/Applications/D-Browser.AppImage; cp build/icon.png ~/.local/share/icons/d-browser.png
  printf '[Desktop Entry]\nType=Application\nName=D Browser\nExec=%s/Applications/D-Browser.AppImage --no-sandbox\nIcon=%s/.local/share/icons/d-browser.png\nCategories=Network;WebBrowser;\n' "$HOME" "$HOME" > ~/.local/share/applications/d-browser.desktop
  RUN="$HOME/Applications/D-Browser.AppImage --no-sandbox"
fi
if ask "D Browser is installed. Launch it now?" "Launch" "Finish"; then nohup $RUN >/dev/null 2>&1 & fi
