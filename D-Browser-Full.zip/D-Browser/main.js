const { app, BrowserWindow, ipcMain, protocol, net, session, dialog, Menu, shell } = require('electron');
const path = require('path'), fs = require('fs'), { pathToFileURL } = require('url');
protocol.registerSchemesAsPrivileged([{ scheme: 'dbr', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } }]);
if (!app.requestSingleInstanceLock()) app.quit();
// look like normal Chrome so Google and other sites accept sign-in
app.userAgentFallback = app.userAgentFallback.replace(/\s?Electron\/\S+/, '').replace(/\s?d-browser\/\S+/i, '').replace(/\s?D Browser\/\S+/i, '');
const root = path.join(__dirname, 'app');
let win, blocker = null, on = true, count = 0;
const sess = new Set(), enabled = new Set(), dls = [];
const BASIC = ['*://*.doubleclick.net/*', '*://*.googlesyndication.com/*', '*://*.googleadservices.com/*', '*://*.google-analytics.com/*', '*://*.adservice.google.com/*', '*://*.youtube.com/api/stats/ads*', '*://*.youtube.com/pagead/*', '*://*.youtube.com/get_midroll_*', '*://*.taboola.com/*', '*://*.outbrain.com/*', '*://*.adnxs.com/*'];
function sync(ses) {
  if (!blocker) return;
  if (on && !enabled.has(ses)) { blocker.enableBlockingInSession(ses); enabled.add(ses); }
  else if (!on && enabled.has(ses)) { blocker.disableBlockingInSession(ses); enabled.delete(ses); }
}
function protect(ses) {
  if (sess.has(ses)) return; sess.add(ses);
  ses.on('will-download', (e, item) => { const d = { name: item.getFilename(), state: 'downloading' }; dls.unshift(d); item.once('done', (_, s) => { d.state = s; d.path = item.getSavePath(); }); });
  ses.webRequest.onBeforeRequest({ urls: BASIC }, (det, cb) => { if (on && !blocker) { count++; cb({ cancel: true }); } else cb({}); });
  sync(ses);
}
async function loadBlocker() {
  try {
    const { ElectronBlocker } = require('@ghostery/adblocker-electron'), fetch = require('cross-fetch');
    const b = await ElectronBlocker.fromPrebuiltAdsAndTrackingLists(fetch, { path: path.join(app.getPath('userData'), 'adblock-engine.bin'), read: fs.promises.readFile, write: fs.promises.writeFile });
    b.on('request-blocked', () => count++);
    blocker = b; sess.forEach(sync);
  } catch (e) { console.log('Full ad-block lists unavailable, using the basic list:', e.message); }
}
function create(priv) {
  win = new BrowserWindow({ width: 1280, height: 800, minWidth: 700, minHeight: 480, title: 'D Browser', icon: path.join(__dirname, 'build/icon.png'), backgroundColor: '#120e2b', frame: false, webPreferences: { nodeIntegration: true, contextIsolation: false, webviewTag: true } });
  win.webContents.setWindowOpenHandler(() => ({ action: 'allow', overrideBrowserWindowOptions: { frame: false, autoHideMenuBar: true, webPreferences: { nodeIntegration: true, contextIsolation: false, webviewTag: true } } }));
  win.loadURL('dbr://app/index.html' + (priv ? '?private' : ''));
}
app.on('web-contents-created', (_, wc) => {
  if (wc.getType() !== 'webview') return;
  const host = wc.hostWebContents; protect(wc.session);
  wc.setWindowOpenHandler(({ url }) => { host.send('open-url', url); return { action: 'deny' }; });
  wc.on('before-input-event', (e, i) => { const k = (i.key || '').toLowerCase(); if (i.type === 'keyDown' && i.control && k.length === 1 && 'twj'.includes(k)) { e.preventDefault(); host.send('key', k); } });
});
ipcMain.on('adblock', (e, v) => { on = !!v; sess.forEach(sync); });
const cfg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'update.json'), 'utf8')); } catch { return {}; } })();
const newer = (a, b) => { const x = String(a).replace(/^v/, '').split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) > (y[i] || 0)) return true; if ((x[i] || 0) < (y[i] || 0)) return false; } return false; };
async function checkUpdate() {
  const cur = app.getVersion();
  try {
    let v, url;
    if (cfg.repo) { const r = await net.fetch(`https://api.github.com/repos/${cfg.repo}/releases/latest`, { headers: { 'User-Agent': 'D-Browser' } }); if (!r.ok) throw new Error('HTTP ' + r.status); const j = await r.json(); v = j.tag_name; url = j.html_url; }
    else if (cfg.versionUrl) { const r = await net.fetch(cfg.versionUrl); if (!r.ok) throw new Error('HTTP ' + r.status); const j = await r.json(); v = j.version; url = j.url; }
    else return 'Updates are not set up yet: put your GitHub repo in update.json.';
    if (newer(v, cur)) { const u = { version: String(v).replace(/^v/, ''), current: cur, url }; BrowserWindow.getAllWindows().forEach(w => w.webContents.send('update', u)); return 'Update ' + u.version + ' is available.'; }
    return 'You have the latest version (' + cur + ').';
  } catch (e) { return 'Could not check for updates: ' + e.message; }
}
ipcMain.handle('check-update', () => checkUpdate());
ipcMain.on('open-external', (e, u) => { if (/^https:\/\//.test(u)) shell.openExternal(u); });
ipcMain.on('win', (e, a) => { const w = BrowserWindow.fromWebContents(e.sender); if (!w) return; if (a === 'min') w.minimize(); else if (a === 'max') w.isMaximized() ? w.unmaximize() : w.maximize(); else if (a === 'close') w.close(); });
ipcMain.on('dls', e => { e.returnValue = dls; });
ipcMain.handle('loadext', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'], title: 'Choose an unpacked extension folder' });
  if (r.canceled) return '';
  try { return (await session.fromPartition('persist:main').loadExtension(r.filePaths[0])).name; } catch (err) { return 'Error: ' + err.message; }
});
setInterval(() => BrowserWindow.getAllWindows().forEach(w => w.webContents.send('count', count)), 1500);
app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  protocol.handle('dbr', r => {
    let p = decodeURIComponent(new URL(r.url).pathname); if (p.endsWith('/')) p += 'index.html';
    const f = path.normalize(path.join(root, p));
    if (!f.startsWith(root)) return new Response('', { status: 403 });
    return net.fetch(pathToFileURL(f).toString());
  });
  create(process.argv.includes('--private')); loadBlocker(); setTimeout(checkUpdate, 15000); setInterval(checkUpdate, 6 * 3600 * 1000);
});
app.on('second-instance', () => { if (win && !win.isDestroyed()) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
