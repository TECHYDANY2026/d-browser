D BROWSER 1.1.1 - FULL PACKAGE

A) REMOVE THE OLD VERSION (do this first)
   Installed from the wizard (app menu):
       sudo apt remove d-browser
       rm -f ~/Desktop/d-browser.desktop
   Installed as portable (AppImage):
       rm -f ~/Applications/D-Browser.AppImage ~/.local/share/applications/d-browser.desktop ~/.local/share/icons/d-browser.png
   Old settings, history and ad-block cache (optional - skip to keep them):
       rm -rf ~/.config/"D Browser" ~/.config/d-browser
   Old download folder and zip:
       rm -rf ~/Downloads/D-Browser ~/Downloads/D-Browser-Full.zip
   (Or run ./install-wizard.sh --uninstall inside the old folder: it does the first part for you.)
   Installing the new version over the old one also works: it upgrades in place and keeps your settings.

B) INSTALL THE NEW VERSION
   1. Extract D-Browser-Full.zip (for example into ~/Downloads).
   2. Open a terminal in the D-Browser folder and run:   bash install-wizard.sh
      (Needs internet and Node.js 18+. It takes about 5-15 minutes.)
   3. Follow the wizard: Next > accept license > install type > it builds and installs.
   Manual way:  npm install  ->  npm start (test)  ->  npm run dist:linux

C) UPDATE NOTIFICATIONS
   D Browser checks for new versions 15 seconds after it starts and every 6 hours, and from the menu: "Check for updates".
   When a newer version exists, a purple bar appears: "D Browser X is available" with a Download update button.
   To turn it on, edit update.json (before building):
       { "repo": "TECHYDANY2026/d-browser", "versionUrl": "" }
   "repo" is a GitHub repository where you publish each new version as a Release (tag like v1.2.0).
   Or set "versionUrl" to a link to a file like: { "version": "1.2.0", "url": "https://your-download-page" }
   To publish an update: raise "version" in package.json, run npm run dist:linux, upload the new files, publish the release.

WINDOWS: npm run dist:win on a Windows PC -> dist/D Browser Setup.exe.   MAC: npm run dist:mac on a Mac.
